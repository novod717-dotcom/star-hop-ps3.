# STAR HOP — demo de homebrew para PS3

Mini jogo 2D de reflexo criado do zero: mova o personagem, pule os blocos e tente fazer a maior pontuação. O pacote inclui o código C para PS3, uma prévia HTML para navegador e um workflow de GitHub Actions.

## Controles

- DualShock 3: analógico esquerdo ou direcional move; X/O ou direcional para cima pula; Start reinicia depois de perder.
- Navegador: setas movem, Espaço ou ↑ pula, Enter reinicia. Também aceita controle Bluetooth via Gamepad API.

## Compilar pelo GitHub usando celular

1. Crie um repositório novo no GitHub.
2. Envie `STARHOP_PS3.zip` para a página principal do repositório usando **Add file → Upload files** e confirme em **Commit changes**.
3. No repositório, toque em **Add file → Create new file**.
4. No nome do arquivo, digite `.github/workflows/build.yml`.
5. Cole o conteúdo do arquivo `.github/workflows/build.yml` que veio dentro do ZIP e confirme em **Commit changes**.
6. Abra a aba **Actions**, selecione **Build STAR HOP PS3** e toque em **Run workflow**. Também executa quando você enviar uma alteração.
7. Quando terminar com sinal verde, abra a execução, vá em **Artifacts** e baixe `STAR-HOP-PS3.zip`. Dentro estarão `STARHOP.pkg` e `STARHOP.self`.

O workflow usa um pacote pré-compilado do PS3DEV e compila a SDL2 para PSL1GHT, depois executa `make pkg`. Se alguma etapa ficar vermelha, abra os detalhes da execução para ver o erro: esta toolchain e SDL2 comunitária podem precisar de ajustes e o PKG não foi testado em um PS3 físico. Para instalar um PKG homebrew, o console precisa aceitar homebrew.

Referências de build: [PS3DEV](https://github.com/ps3dev/ps3dev) e [SDL2 para PSL1GHT](https://github.com/sergiou87/SDL2_PSL1GHT).
