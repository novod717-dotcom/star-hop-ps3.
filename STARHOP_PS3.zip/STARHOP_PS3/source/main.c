#include <SDL.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define W 960
#define H 540
#define FLOOR_Y 455
#define PLAYER_W 34
#define PLAYER_H 48
#define MAX_OBS 6

typedef struct { float x, y, w, h; bool active; } Obstacle;

static void rect(SDL_Renderer *r, int x, int y, int w, int h, Uint8 cr, Uint8 cg, Uint8 cb) {
    SDL_Rect q = {x, y, w, h};
    SDL_SetRenderDrawColor(r, cr, cg, cb, 255);
    SDL_RenderFillRect(r, &q);
}

static void digit(SDL_Renderer *r, int n, int x, int y) {
    static const uint8_t bits[10][5] = {
        {7,5,5,5,7},{2,6,2,2,7},{7,1,7,4,7},{7,1,7,1,7},{5,5,7,1,1},
        {7,4,7,1,7},{7,4,7,5,7},{7,1,1,1,1},{7,5,7,5,7},{7,5,7,1,7}
    };
    for (int row=0; row<5; ++row) for (int col=0; col<3; ++col)
        if (bits[n%10][row] & (1u << (2-col))) rect(r,x+col*4,y+row*4,3,3,245,247,255);
}

static void label(SDL_Renderer *r, const char *s, int x, int y, int scale) {
    static const uint8_t font[26][7] = {
        {14,17,17,31,17,17,17},{30,17,17,30,17,17,30},{14,17,16,16,16,17,14},
        {30,17,17,17,17,17,30},{31,16,16,30,16,16,31},{31,16,16,30,16,16,16},
        {14,17,16,23,17,17,15},{17,17,17,31,17,17,17},{14,4,4,4,4,4,14},
        {7,2,2,2,2,18,12},{17,18,20,24,20,18,17},{16,16,16,16,16,16,31},
        {17,27,21,21,17,17,17},{17,25,21,19,17,17,17},{14,17,17,17,17,17,14},
        {30,17,17,30,16,16,16},{14,17,17,17,21,18,13},{30,17,17,30,20,18,17},
        {15,16,16,14,1,1,30},{31,4,4,4,4,4,4},{17,17,17,17,17,17,14},
        {17,17,17,17,17,10,4},{17,17,17,21,21,21,10},{17,17,10,4,10,17,17},
        {17,17,10,4,4,4,4},{31,1,2,4,8,16,31}
    };
    for (int i=0; s[i]; ++i) {
        char c=s[i]; if(c>='a'&&c<='z') c=(char)(c-'a'+'A');
        if(c>='A'&&c<='Z') for(int row=0;row<7;++row) for(int col=0;col<5;++col)
            if(font[c-'A'][row]&(1u<<(4-col))) rect(r,x+i*6*scale+col*scale,y+row*scale,scale,scale,245,247,255);
    }
}

static bool hit(float ax,float ay,float aw,float ah,float bx,float by,float bw,float bh) {
    return ax < bx+bw && ax+aw > bx && ay < by+bh && ay+ah > by;
}

int main(int argc, char **argv) {
    (void)argc; (void)argv;
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_GAMECONTROLLER | SDL_INIT_JOYSTICK) != 0) return 1;
    SDL_Window *win = SDL_CreateWindow("STAR HOP", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, W, H, SDL_WINDOW_FULLSCREEN);
    if (!win) win = SDL_CreateWindow("STAR HOP", SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED, W, H, 0);
    if (!win) { SDL_Quit(); return 2; }
    SDL_Renderer *ren = SDL_CreateRenderer(win,-1,SDL_RENDERER_ACCELERATED|SDL_RENDERER_PRESENTVSYNC);
    if (!ren) ren = SDL_CreateRenderer(win,-1,SDL_RENDERER_SOFTWARE);
    if (!ren) { SDL_DestroyWindow(win); SDL_Quit(); return 3; }
    SDL_RenderSetLogicalSize(ren,W,H);
    SDL_GameController *pad = NULL;
    for (int i=0; i<SDL_NumJoysticks(); ++i) if (SDL_IsGameController(i)) { pad=SDL_GameControllerOpen(i); if(pad) break; }
    if (!pad && SDL_NumJoysticks()>0) SDL_JoystickOpen(0);

    srand((unsigned)time(NULL));
    float px=140, py=FLOOR_Y-PLAYER_H, vy=0, speed=6.0f;
    Obstacle obs[MAX_OBS]={{0}};
    int score=0, best=0, spawn=0;
    bool grounded=true, alive=true, running=true;
    Uint32 last=SDL_GetTicks();
    while (running) {
        Uint32 now=SDL_GetTicks(); float dt=(now-last)/16.6667f; last=now;
        if(dt>2.5f) dt=2.5f;
        bool jump=false, left=false, right=false;
        SDL_Event e;
        while(SDL_PollEvent(&e)) {
            if(e.type==SDL_QUIT) running=false;
            if(e.type==SDL_KEYDOWN && !e.key.repeat) {
                if(e.key.keysym.sym==SDLK_ESCAPE) running=false;
                if(e.key.keysym.sym==SDLK_SPACE || e.key.keysym.sym==SDLK_UP) jump=true;
                if(e.key.keysym.sym==SDLK_LEFT) left=true;
                if(e.key.keysym.sym==SDLK_RIGHT) right=true;
                if(e.key.keysym.sym==SDLK_RETURN && !alive) { alive=true; score=0; px=140; py=FLOOR_Y-PLAYER_H; vy=0; }
            }
            if(e.type==SDL_CONTROLLERBUTTONDOWN) {
                if(e.cbutton.button==SDL_CONTROLLER_BUTTON_A || e.cbutton.button==SDL_CONTROLLER_BUTTON_B || e.cbutton.button==SDL_CONTROLLER_BUTTON_DPAD_UP) jump=true;
                if(e.cbutton.button==SDL_CONTROLLER_BUTTON_START && !alive) { alive=true; score=0; px=140; py=FLOOR_Y-PLAYER_H; vy=0; }
            }
            if(e.type==SDL_CONTROLLERAXISMOTION && e.caxis.axis==SDL_CONTROLLER_AXIS_LEFTX) {
                if(e.caxis.value < -9000) left=true; if(e.caxis.value > 9000) right=true;
            }
            if(e.type==SDL_JOYBUTTONDOWN && (e.jbutton.button==0 || e.jbutton.button==1)) jump=true;
            if(e.type==SDL_JOYAXISMOTION && e.jaxis.axis==0) { if(e.jaxis.value < -9000) left=true; if(e.jaxis.value > 9000) right=true; }
        }
        const Uint8 *keys=SDL_GetKeyboardState(NULL);
        if(keys[SDL_SCANCODE_SPACE]||keys[SDL_SCANCODE_UP]) jump=true;
        if(keys[SDL_SCANCODE_LEFT]) left=true; if(keys[SDL_SCANCODE_RIGHT]) right=true;
        if(pad) {
            if(SDL_GameControllerGetButton(pad,SDL_CONTROLLER_BUTTON_A)||SDL_GameControllerGetButton(pad,SDL_CONTROLLER_BUTTON_B)||SDL_GameControllerGetButton(pad,SDL_CONTROLLER_BUTTON_DPAD_UP)) jump=true;
            Sint16 ax=SDL_GameControllerGetAxis(pad,SDL_CONTROLLER_AXIS_LEFTX); if(ax < -9000) left=true; if(ax > 9000) right=true;
        }
        if(alive) {
            if(jump && grounded) { vy=-14.0f; grounded=false; }
            if(left) px-=5.0f*dt; if(right) px+=5.0f*dt;
            if(px<25) px=25; if(px>W-PLAYER_W-25) px=W-PLAYER_W-25;
            vy+=0.72f*dt; py+=vy*dt;
            if(py>=FLOOR_Y-PLAYER_H) { py=FLOOR_Y-PLAYER_H; vy=0; grounded=true; }
            speed=6.0f+(score/500)*0.45f;
            if(++spawn > (int)(75.0f/speed*6.0f)) {
                for(int i=0;i<MAX_OBS;i++) if(!obs[i].active) { obs[i]=(Obstacle){W+20,FLOOR_Y-34,28,34,true}; break; }
                spawn=0;
            }
            for(int i=0;i<MAX_OBS;i++) if(obs[i].active) {
                obs[i].x-=speed*dt;
                if(obs[i].x+obs[i].w<0) { obs[i].active=false; score+=10; }
                if(hit(px+4,py+4,PLAYER_W-8,PLAYER_H-4,obs[i].x+3,obs[i].y+3,obs[i].w-6,obs[i].h-3)) { alive=false; if(score>best)best=score; }
            }
            score+=(int)(dt*0.45f);
        }
        SDL_SetRenderDrawColor(ren,12,18,42,255); SDL_RenderClear(ren);
        for(int i=0;i<24;i++) { int sx=(i*173+(now/40)*(i%3+1))%W; int sy=(i*97)%370; rect(ren,sx,sy,3,3,95,127,190); }
        rect(ren,0,FLOOR_Y,W,H-FLOOR_Y,22,31,61);
        rect(ren,0,FLOOR_Y,W,5,94,240,205);
        for(int i=0;i<16;i++) rect(ren,(i*79-(int)(now/7)%79),FLOOR_Y+24,35,3,38,51,83);
        for(int i=0;i<MAX_OBS;i++) if(obs[i].active) { rect(ren,(int)obs[i].x,(int)obs[i].y,(int)obs[i].w,(int)obs[i].h,255,115,94); rect(ren,(int)obs[i].x+6,(int)obs[i].y+7,5,5,255,211,160); }
        rect(ren,(int)px,(int)py,PLAYER_W,PLAYER_H,95,240,205);
        rect(ren,(int)px+21,(int)py+11,5,5,12,18,42);
        rect(ren,24,24,116,44,27,39,72); int v=score; int places=1; for(int t=v;t>=10;t/=10)places++; for(int i=places-1;i>=0;i--){digit(ren,v%10,38+i*16,32);v/=10;}
        if(!alive) {
            rect(ren,260,160,440,185,27,39,72); label(ren,"GAME OVER",390,195,4); label(ren,"APERTE X",402,255,3); rect(ren,390,300,180,5,94,240,205);
        }
        SDL_RenderPresent(ren);
    }
    if(pad) SDL_GameControllerClose(pad);
    SDL_DestroyRenderer(ren); SDL_DestroyWindow(win); SDL_Quit();
    return 0;
}
